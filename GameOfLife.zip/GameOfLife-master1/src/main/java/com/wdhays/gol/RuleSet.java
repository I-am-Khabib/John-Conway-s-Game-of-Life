package main.java.com.wdhays.gol;

import java.util.ArrayList;
import java.util.List;

public enum RuleSet {

    /*
    * Note: Game of Life rules can be represented by a string E.g. 23/3
    * where the numbers before the slash represent the number of living neighbors
    * a living cell needs to stay alive in the next generation and the numbers
    * after the slash represent the number of living neighbors a dead cell needs
    * to come to life in the next generation. The aliveRules and deadRules are
    * an interpretation of this that can be easily searched using a binary search
    * when determining a cells state in the next generation using their living
    * neighbor count.
    */
    STANDARD("Standard", new int[] {2,3}, new int[] {3});
    private String label;
    private int[] aliveRules; //Rules that apply to cells currently alive.
    private int[] deadRules; //Rules that apply to cells currently dead.

    RuleSet(String label, int[] aliveRules, int[] deadRules) {
        this.label = label;
        this.aliveRules = aliveRules;
        this.deadRules = deadRules;
    }

    public String getLabel() {
        return label;
    }

    public static List<String> getRuleSetLabels() {
        List<String> allLabels = new ArrayList<>();
        for (RuleSet ruleSet : RuleSet.values()) {
            allLabels.add(ruleSet.getLabel());
        }
        return allLabels;
    }

    public static RuleSet fromString(String text) {
        for (RuleSet ruleSet : RuleSet.values()) {
            if (ruleSet.label.equalsIgnoreCase(text)) {
                return ruleSet;
            }
        }
        return null;
    }

    public int[] getAliveRules() {
        return aliveRules;
    }

    public int[] getDeadRules() {
        return deadRules;
    }
}
